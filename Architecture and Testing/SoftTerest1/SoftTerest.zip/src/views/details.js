const section = document.getElementById("detailsView");

export function showDetails(context) {
    context.showSection(section)
}