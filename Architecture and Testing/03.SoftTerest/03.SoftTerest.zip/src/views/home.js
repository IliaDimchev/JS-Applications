const section = document.querySelector('#homeView');

export function showHome(context){
    context.showSection(section);
}