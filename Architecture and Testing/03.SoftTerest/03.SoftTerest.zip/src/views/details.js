const section = document.querySelector('#detailsView');

export function showDetails(context){
    context.showSection(section);
}